﻿using ExcelTest.BLL.Interface;
using ExcelTest.DAT;
using ExcelTest.Models;
using ExcelTest.Models.ViewModel;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ExcelTest.Controllers
{
    public class ExpenseCategoryController : Controller
    {
        private readonly ExcelDbContext _context;
        public ExpenseCategoryController(ExcelDbContext context)
        {
            _context = context;
        }
        [HttpGet]
        public ActionResult Index(int pageNumber = 1)
        {
            List<ExpenseCategory> expenseCategories = _context.ExpenseCategories.ToList();
            return View(expenseCategories);
        }
        [HttpGet]
        public ActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Create(CreateExpenseCategoryViewModel viewObj)
        {
            ExpenseCategory expenseCategory = new ExpenseCategory();
            expenseCategory.ExpenseCategoryName = viewObj.ExpenseCategoryName;
            _context.ExpenseCategories.Add(expenseCategory);
            _context.SaveChanges();
            return RedirectToAction("Index");
        }
        [HttpGet]
        public ActionResult Edit(int id)
        {
            ExpenseCategory expCateObj = _context.ExpenseCategories.SingleOrDefault(E => E.ExpenseCategoryId == id);
            CreateExpenseCategoryViewModel expCate1 = new CreateExpenseCategoryViewModel();
            if (expCateObj != null)
            {
                expCate1.ExpenseCategoryName = expCateObj.ExpenseCategoryName;
            }
            return View(expCateObj);
        }
        [HttpPost]
        public ActionResult Edit(CreateExpenseCategoryViewModel viewObj)
        {
            ExpenseCategory obj = new ExpenseCategory();
            obj.ExpenseCategoryId = viewObj.ExpenseCategoryId;
            obj.ExpenseCategoryName = viewObj.ExpenseCategoryName;
            _context.Entry(obj).State = EntityState.Modified;
            _context.SaveChanges();
            return RedirectToAction("Index");
        }
        [HttpGet, HttpPost]
        public ActionResult Delete(int id)
        {
            ExpenseCategory ExpObj = _context.ExpenseCategories.SingleOrDefault(g => g.ExpenseCategoryId == id);
            if (ExpObj != null)
            {
                _context.ExpenseCategories.Remove(ExpObj);
                _context.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(ExpObj);
        }
    }
}
