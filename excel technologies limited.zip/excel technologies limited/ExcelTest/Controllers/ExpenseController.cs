﻿using Microsoft.AspNetCore.Authorization;
using ExcelTest.DAT;
using ExcelTest.Models;
using ExcelTest.Models.ViewModel;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PagedList;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ExcelTest.BLL.Interface;

namespace ExcelTest.Controllers
{
    public class ExpenseController : Controller
    {
        private readonly IExpenseCatagoryRepository _repoObj;
        private readonly IWebHostEnvironment _hostingEnvironment;
        private readonly ExcelDbContext _context;
        public ExpenseController(IExpenseCatagoryRepository repoObj, IWebHostEnvironment hostEnvironment, ExcelDbContext context)
        {
            _hostingEnvironment = hostEnvironment;
            _context = context;
            _repoObj = repoObj  ;
        }
        [HttpGet]
        [AllowAnonymous]
        public ActionResult Index(string SearchString, string CurrentFilter, string sortOrder, int? Page)
        {
            var applicationDbContext = _context.Expenses.Include(c => c.ExpenseCategory.ExpenseCategoryName);
            ViewBag.SortNameParam = string.IsNullOrEmpty(sortOrder) ? "name_des" : "";
            if (SearchString != null)
            {
                Page = 1;
            }
            else
            {
                SearchString = CurrentFilter;
            }
            ViewBag.CurrentFilter = SearchString;
            List<ExpenseListViewModel> ExpList = _context.Expenses.Select(p => new ExpenseListViewModel
            {
                ExpenseId = p.ExpenseId,
                DateOfTheExpense = p.DateOfTheExpense,
                TypeOfTheExpenseAmount = p.TypeOfTheExpenseAmount,
                ExpenseCategoryId = p.ExpenseCategoryId,
                ExpenseCategoryName = p.ExpenseCategory.ExpenseCategoryName,
            }).ToList();

            if (!string.IsNullOrEmpty(SearchString))
            {
                ExpList = ExpList.Where(n => n.ExpenseCategoryName.ToUpper().Contains(SearchString.ToUpper())).ToList();
            }
            switch (sortOrder)
            {
                case "name_des":
                    ExpList = ExpList.OrderByDescending(n => n.ExpenseCategoryName).ToList();
                    break;
                default:
                    ExpList = ExpList.OrderBy(n => n.ExpenseCategoryName).ToList();
                    break;
            }
            int PageSize = 100;
            int PageNumber = (Page ?? 1);
            return View("Index", ExpList.ToPagedList(PageNumber, PageSize));
        }
        [HttpGet]
        public ActionResult Create()
        {
            CreateExpenseViewModel crObj = new CreateExpenseViewModel();
            crObj.ExpenseCategories = _context.ExpenseCategories.ToList();
            return View(crObj);
        }
        public ActionResult AddOrEdit(CreateExpenseViewModel viewObj)
        {
            var result = false;
            Expense Obj = new Expense();
            Obj.DateOfTheExpense = viewObj.DateOfTheExpense;
            Obj.TypeOfTheExpenseAmount = viewObj.TypeOfTheExpenseAmount;
            Obj.ExpenseCategoryId = viewObj.ExpenseCategoryId;
            if (ModelState.IsValid)
            {
                if (viewObj.ExpenseId == 0)
                {
                    _context.Expenses.Add(Obj);
                    _context.SaveChanges();
                    result = true;
                }
                else
                {
                    Obj.ExpenseId = viewObj.ExpenseId;
                    _context.Entry(Obj).State = EntityState.Modified;
                    _context.SaveChanges();
                    result = true;
                }
            }
            if (result)
            {
                return RedirectToAction("Index");
            }
            else
            {
                if (viewObj.ExpenseId == 0)
                {
                    CreateExpenseViewModel crObj = new CreateExpenseViewModel();
                    crObj.ExpenseCategories = _context.ExpenseCategories.ToList();
                    return View("Create", crObj);
                }
                else
                {
                    CreateExpenseViewModel crObj = new CreateExpenseViewModel();
                    crObj.ExpenseCategories = _context.ExpenseCategories.ToList();
                    return View("Edit", crObj);
                }
            }
        }
        public ActionResult Edit(int id)
        {
            Expense Obj = _context.Expenses.SingleOrDefault(p => p.ExpenseId == id);
            CreateExpenseViewModel viewObj = new CreateExpenseViewModel();
            if (Obj != null)
            {
                viewObj.ExpenseId = Obj.ExpenseId;
                viewObj.DateOfTheExpense = Obj.DateOfTheExpense;
                viewObj.TypeOfTheExpenseAmount = Obj.TypeOfTheExpenseAmount;
                viewObj.ExpenseCategoryId = Obj.ExpenseCategoryId;
                //viewObj.ExpenseCategoryName = Obj.ExpenseCategory.ExpenseCategoryName;
                viewObj.ExpenseCategories = _context.ExpenseCategories.ToList();
            }
            return View(viewObj);
        }
        [HttpGet]
        public ActionResult Delete(int id)
        {
            Expense ExpObj = _context.Expenses.SingleOrDefault(p => p.ExpenseId == id);
            CreateExpenseViewModel viewObj = new CreateExpenseViewModel();
            if (ExpObj != null)
            {
                viewObj.ExpenseId = ExpObj.ExpenseId;
                viewObj.DateOfTheExpense = ExpObj.DateOfTheExpense;
                viewObj.TypeOfTheExpenseAmount = ExpObj.TypeOfTheExpenseAmount;
                viewObj.ExpenseCategoryId = ExpObj.ExpenseCategoryId;
            }
            return View(viewObj);
        }
        [HttpPost]
        [ActionName("Delete")]
        public ActionResult DeleteConfirm(int id)
        {
            Expense ExpObj = _context.Expenses.SingleOrDefault(p => p.ExpenseId == id);
            if (ExpObj != null)
            {
                _context.Expenses.Remove(ExpObj);
                _context.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(ExpObj);
        }
    }
}
