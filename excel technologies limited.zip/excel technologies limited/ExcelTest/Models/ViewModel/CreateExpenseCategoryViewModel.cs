﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace ExcelTest.Models.ViewModel
{
    public class CreateExpenseCategoryViewModel
    {
        public int ExpenseCategoryId { get; set; }
        [Display(Name ="ExpenseCategoryName")]
        [Required(ErrorMessage = "ExpenseCategoryName Is Required")]
        public string ExpenseCategoryName { get; set; }
    }
}
