﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ExcelTest.Models.ViewModel
{
    public class ExpenseListViewModel
    {
        public int ExpenseId { get; set; }
        public DateTime DateOfTheExpense { get; set; }
        public Decimal TypeOfTheExpenseAmount { get; set; }
        public int ExpenseCategoryId { get; set; }
        public string ExpenseCategoryName { get; set; }
        public virtual ExpenseCategory ExpenseCategory { get; set; }
    }
}
