﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ExcelTest.Models.ViewModel
{
    public class ExpenseCategoryListViewModel
    {
        public int ExpenseCategoryId { get; set; }
        public string ExpenseCategoryName { get; set; }
       
    }
}
