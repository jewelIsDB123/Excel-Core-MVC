﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace ExcelTest.Models.ViewModel
{
    public class CreateExpenseViewModel
    {
        public int ExpenseId { get; set; }

        [Required(ErrorMessage = "Please enter DateOfTheExpense")]
        [Display(Name = "DateOfTheExpense")]
        [DataType(DataType.Date)]
        public DateTime DateOfTheExpense { get; set; }
        [Required(ErrorMessage = "Please enter TypeOfTheExpenseAmount")]
        public Decimal TypeOfTheExpenseAmount { get; set; }
        public int ExpenseCategoryId { get; set; }
        public string ExpenseCategoryName { get; set; }
        public List<ExpenseCategory> ExpenseCategories { get; set; }
    }
}
