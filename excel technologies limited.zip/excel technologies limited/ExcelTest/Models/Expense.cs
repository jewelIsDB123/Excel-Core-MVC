﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace ExcelTest.Models
{
    public class Expense
    {
        public int ExpenseId { get; set; } 
        public DateTime DateOfTheExpense { get; set; }
        public Decimal TypeOfTheExpenseAmount { get; set; }
        public int ExpenseCategoryId { get; set; }
        public virtual ExpenseCategory ExpenseCategory { get; set; }
    }
}
