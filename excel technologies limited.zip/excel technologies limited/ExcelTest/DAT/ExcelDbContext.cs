﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using ExcelTest.Models;
namespace ExcelTest.DAT
{
    public class ExcelDbContext: DbContext
    {
        public ExcelDbContext(DbContextOptions<ExcelDbContext> options):base(options)
        {
        }
        public DbSet<Expense> Expenses { get; set; }
        public DbSet<ExpenseCategory> ExpenseCategories { get; set; }
    }
}
