﻿using ExcelTest.Models;
using ExcelTest.Models.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ExcelTest.BLL.Interface
{
    public interface IExpenseCatagoryRepository
    {

        List<ExpenseListViewModel> GetExpenseListViews();
        List<CreateExpenseViewModel> GetCreateExpenseViews();
        void SaveExpense(Expense obj);
        void UpdateExpese(Expense obj);
        void DeleteExpese(int id);
        Expense GetExpenseById(int id);

        List<ExpenseCategory> GetExpenseCategories();
        ExpenseCategory GetExpenseCategoryById(int ExpenseCategoryId);
        void SaveExpenseCategory(ExpenseCategory obj);
        void UdpateExpenseCategory(ExpenseCategory obj);
        void DeleteExpenseCategory(int id);
    }
}
