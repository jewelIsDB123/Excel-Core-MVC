﻿using ExcelTest.BLL.Interface;
using ExcelTest.DAT;
using ExcelTest.Models;
using ExcelTest.Models.ViewModel;
using Microsoft.AspNetCore.Authorization;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ExcelTest.BLL.Repository
{
    
    public class ExpenseCatagoryRepository : IExpenseCatagoryRepository
    {
        private readonly ExcelDbContext _context;
        public ExpenseCatagoryRepository(ExcelDbContext context)
        {
            _context = context;
        }

        public void DeleteExpenseCategory(int id)
        {
             ExpenseCategory delExpCate = GetExpenseCategoryById(id);
            _context.ExpenseCategories.Remove(delExpCate);
            _context.SaveChanges();
        }

        public List<CreateExpenseViewModel> GetCreateExpenseViews()
        {
            List<CreateExpenseViewModel> createExpenseViewModels = new List<CreateExpenseViewModel>();
            createExpenseViewModels = _context.Expenses.Select(p => new CreateExpenseViewModel
            {
                DateOfTheExpense = p.DateOfTheExpense,
                TypeOfTheExpenseAmount=p.TypeOfTheExpenseAmount,
                ExpenseCategoryId=p.ExpenseCategory.ExpenseCategoryId
            }).ToList();
            return createExpenseViewModels;
        }

        public Expense GetExpenseById(int id)
        {
            Expense expense = _context.Expenses.SingleOrDefault(p => p.ExpenseId == id);
            return expense;
        }

        public List<ExpenseCategory> GetExpenseCategories()
        {
            List<ExpenseCategory> expenseCategories = _context.ExpenseCategories.ToList();
            return expenseCategories;
        }

        public ExpenseCategory GetExpenseCategoryById(int ExpenseCategoryId)
        {
            ExpenseCategory expenseCategory = _context.ExpenseCategories.SingleOrDefault(g => g.ExpenseCategoryId == ExpenseCategoryId);
            return expenseCategory;
        }

        public List<ExpenseListViewModel> GetExpenseListViews()
        {
            List<ExpenseListViewModel> list = _context.Expenses.Select(p => new ExpenseListViewModel
            {
                ExpenseId=p.ExpenseId,
                DateOfTheExpense=p.DateOfTheExpense,
                TypeOfTheExpenseAmount=p.TypeOfTheExpenseAmount,
                ExpenseCategoryId=p.ExpenseCategoryId,
                ExpenseCategoryName=p.ExpenseCategory.ExpenseCategoryName,
            }).ToList();
            return list;
        }

        public void SaveExpense(Expense obj)
        {
            _context.Expenses.Add(obj);
            _context.SaveChanges();
        }

        public void SaveExpenseCategory(ExpenseCategory obj)
        {
            _context.ExpenseCategories.Add(obj);
            _context.SaveChanges();
        }

        public void UdpateExpenseCategory(ExpenseCategory obj)
        {
            _context.Entry(obj).State = EntityState.Modified;
            _context.SaveChanges();
        }

        public void UpdateExpese(Expense obj)
        {
            _context.Entry(obj).State = EntityState.Modified;
            _context.SaveChanges();
        }
        public void DeleteExpese(int id)
        {
            Expense expense = GetExpenseById(id);
            _context.Expenses.Remove(expense);
            _context.SaveChanges();

        }
    }
}
